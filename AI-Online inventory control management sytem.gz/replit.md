# Workspace

## Overview

pnpm workspace monorepo using TypeScript. AI-powered Online Inventory Control Management System.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite, Tailwind CSS, shadcn/ui, React Query, Recharts, Framer Motion
- **AI**: OpenAI via Replit AI Integrations (gpt-5.2)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── inventory/          # React + Vite frontend (AI Inventory Control)
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml     # pnpm workspace
├── tsconfig.base.json      # Shared TS options
├── tsconfig.json           # Root TS project references
└── package.json            # Root package with hoisted devDeps
```

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all packages as project references.

- **Always typecheck from the root** — run `pnpm run typecheck`
- **`emitDeclarationOnly`** — only `.d.ts` files during typecheck; actual JS bundling is by esbuild/tsx/vite

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references

## Packages

### `artifacts/inventory` (`@workspace/inventory`)

React + Vite frontend for the AI Inventory Control System. Serves at `/`.

Pages:
- **Dashboard** — KPI stats, inventory value chart, AI insights panel
- **Products** — Full CRUD with search/filter by category and low stock
- **Stock Movements** — Record in/out/adjustment, movement history
- **Categories** — Category management
- **Low Stock Alerts** — Products below minimum quantity threshold
- **AI Insights** — AI-powered inventory analysis and recommendations

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. All routes under `/api`.

Routes:
- `GET/POST /api/categories` — Category management
- `GET/POST/PUT/DELETE /api/products` — Product CRUD
- `GET /api/dashboard/stats` — Dashboard KPIs
- `GET/POST /api/movements` — Stock movement recording
- `POST /api/ai/insights` — AI-powered insights via OpenAI

### `lib/db` (`@workspace/db`)

Database schema:
- `categories` — Product categories
- `products` — Products with SKU, quantity, pricing, min stock levels
- `movements` — Stock in/out/adjustment history

Migrations: `pnpm --filter @workspace/db run push`

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI 3.1 spec. Codegen: `pnpm --filter @workspace/api-spec run codegen`

### `lib/api-zod` and `lib/api-client-react`

Generated from OpenAPI spec. Do not edit directly.

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (auto-provided by Replit)
- `AI_INTEGRATIONS_OPENAI_BASE_URL` — Replit AI proxy base URL
- `AI_INTEGRATIONS_OPENAI_API_KEY` — Replit AI integration key
