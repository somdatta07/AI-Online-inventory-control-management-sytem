import { useState, useRef, useEffect } from "react";
import { useAiAssistant, useAiHistory, useAiHistoryMutations } from "@/hooks/use-dashboard";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, User, Send, Sparkles, Loader2, History, Trash2, X, Clock } from "lucide-react";
import { format } from "date-fns";

type Message = {
  role: "user" | "ai";
  content: string;
  recommendations?: string[];
};

export default function AiAssistant() {
  const [query, setQuery] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      content: "Hello! I am your AstraFlow AI assistant. I've analyzed your current inventory levels, movements, and categories. Ask me anything about optimizing your stock, identifying slow-moving items, or planning reorders. All your conversations are saved automatically.",
    },
  ]);

  const aiMutation = useAiAssistant();
  const { data: history, isLoading: isHistoryLoading } = useAiHistory(50);
  const { deleteEntry, clearAll } = useAiHistoryMutations();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, aiMutation.isPending]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || aiMutation.isPending) return;

    const userMessage: Message = { role: "user", content: query };
    setMessages(prev => [...prev, userMessage]);
    setQuery("");

    try {
      const response = await aiMutation.mutateAsync({ data: { query: userMessage.content } });
      setMessages(prev => [
        ...prev,
        {
          role: "ai",
          content: response.insight,
          recommendations: response.recommendations,
        },
      ]);
    } catch {
      setMessages(prev => [
        ...prev,
        { role: "ai", content: "I encountered an error analyzing your data. Please try again." },
      ]);
    }
  };

  const loadFromHistory = (entry: { query: string; insight: string; recommendations: string[] }) => {
    setMessages([
      {
        role: "ai",
        content: "Hello! I am your AstraFlow AI assistant. I've analyzed your current inventory levels, movements, and categories. Ask me anything about optimizing your stock, identifying slow-moving items, or planning reorders. All your conversations are saved automatically.",
      },
      { role: "user", content: entry.query },
      { role: "ai", content: entry.insight, recommendations: entry.recommendations },
    ]);
    setShowHistory(false);
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col max-w-5xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold flex items-center">
            <Sparkles className="w-8 h-8 mr-3 text-primary" />
            AI Insights
          </h1>
          <p className="text-muted-foreground mt-1">Ask questions in plain English to get actionable inventory intelligence.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowHistory(v => !v)}
            className="flex items-center gap-2"
          >
            <History className="w-4 h-4" />
            History
            {history && history.length > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">{history.length}</Badge>
            )}
          </Button>
        </div>
      </div>

      <div className="flex gap-4 flex-1 min-h-0">
        {/* Chat panel */}
        <Card className="flex-1 flex flex-col shadow-lg border-primary/10 overflow-hidden bg-white/50 backdrop-blur-sm">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex gap-4 max-w-[85%] ${msg.role === "user" ? "ml-auto flex-row-reverse" : ""}`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${msg.role === "user" ? "bg-sidebar text-sidebar-foreground" : "bg-primary text-primary-foreground"}`}>
                  {msg.role === "user" ? <User className="w-5 h-5" /> : <Bot className="w-6 h-6" />}
                </div>

                <div className={`space-y-3 ${msg.role === "user" ? "items-end" : ""}`}>
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    msg.role === "user"
                      ? "bg-sidebar text-sidebar-foreground rounded-tr-sm"
                      : "bg-white border border-primary/10 rounded-tl-sm text-foreground"
                  }`}>
                    <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                  </div>

                  {msg.recommendations && msg.recommendations.length > 0 && (
                    <div className="bg-primary/5 border border-primary/10 rounded-xl p-4 shadow-sm">
                      <h4 className="font-semibold text-primary mb-2 text-sm uppercase tracking-wide flex items-center">
                        <Sparkles className="w-4 h-4 mr-2" /> Recommended Actions
                      </h4>
                      <ul className="space-y-2">
                        {msg.recommendations.map((rec, rIdx) => (
                          <li key={rIdx} className="flex items-start text-sm text-foreground/80">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 mr-2 flex-shrink-0" />
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {aiMutation.isPending && (
              <div className="flex gap-4 max-w-[85%]">
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-primary text-primary-foreground shadow-sm">
                  <Bot className="w-6 h-6" />
                </div>
                <div className="p-4 rounded-2xl bg-white border border-primary/10 rounded-tl-sm flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 rounded-full bg-primary/80 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-background border-t border-border">
            <form onSubmit={handleSubmit} className="relative flex items-center">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask about optimizing your stock..."
                className="pr-12 py-6 rounded-xl shadow-inner bg-white border-primary/20 focus-visible:ring-primary/30 text-base"
                disabled={aiMutation.isPending}
              />
              <Button
                type="submit"
                size="icon"
                className="absolute right-2 h-10 w-10 rounded-lg bg-primary hover:bg-primary/90 transition-transform active:scale-95"
                disabled={!query.trim() || aiMutation.isPending}
              >
                {aiMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              </Button>
            </form>
            <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
              <button type="button" onClick={() => setQuery("Which products are taking up the most capital?")} className="text-xs px-3 py-1.5 bg-white border border-border rounded-full hover:bg-muted whitespace-nowrap transition-colors">Capital Allocation</button>
              <button type="button" onClick={() => setQuery("What should I reorder this week?")} className="text-xs px-3 py-1.5 bg-white border border-border rounded-full hover:bg-muted whitespace-nowrap transition-colors">Reorder Planning</button>
              <button type="button" onClick={() => setQuery("Identify dead stock items.")} className="text-xs px-3 py-1.5 bg-white border border-border rounded-full hover:bg-muted whitespace-nowrap transition-colors">Dead Stock</button>
            </div>
          </div>
        </Card>

        {/* History panel */}
        {showHistory && (
          <Card className="w-80 flex flex-col shadow-lg border-primary/10 overflow-hidden">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-sm">Saved Conversations</h3>
              </div>
              <div className="flex items-center gap-1">
                {history && history.length > 0 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    title="Clear all history"
                    onClick={() => clearAll.mutate({})}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-muted-foreground"
                  onClick={() => setShowHistory(false)}
                >
                  <X className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              {isHistoryLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              ) : history && history.length > 0 ? (
                history.map((entry) => (
                  <div
                    key={entry.id}
                    className="group relative rounded-lg border border-border hover:border-primary/30 hover:bg-primary/5 transition-colors cursor-pointer"
                  >
                    <button
                      className="w-full text-left p-3 pr-8"
                      onClick={() => loadFromHistory(entry)}
                    >
                      <p className="text-sm font-medium text-foreground line-clamp-2 leading-tight">{entry.query}</p>
                      <div className="flex items-center gap-1 mt-1.5 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {format(new Date(entry.createdAt), "MMM d, h:mm a")}
                      </div>
                    </button>
                    <button
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded text-muted-foreground hover:text-destructive"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteEntry.mutate({ id: entry.id });
                      }}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                  <History className="w-8 h-8 text-muted-foreground/50 mb-2" />
                  <p className="text-sm text-muted-foreground">No saved conversations yet.</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">Ask a question to get started.</p>
                </div>
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
