import { useState } from "react";
import { useCategories, useCategoryMutations } from "@/hooks/use-categories";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Tags, Loader2, Hash } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

const categorySchema = z.object({
  name: z.string().min(2, "Name is required"),
  description: z.string().optional(),
});

const CATEGORY_COLORS = [
  "#6366f1", "#8b5cf6", "#ec4899", "#06b6d4", "#10b981", "#f59e0b",
];

export default function Categories() {
  const { data: categories, isLoading } = useCategories();
  const { create } = useCategoryMutations();
  const { toast } = useToast();

  const [isModalOpen, setIsModalOpen] = useState(false);

  const form = useForm<z.infer<typeof categorySchema>>({
    resolver: zodResolver(categorySchema),
    defaultValues: { name: "", description: "" },
  });

  const onSubmit = async (data: z.infer<typeof categorySchema>) => {
    try {
      await create.mutateAsync({ data });
      toast({ title: "Category created" });
      setIsModalOpen(false);
      form.reset();
    } catch {
      toast({ title: "Failed to create", variant: "destructive" });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6 max-w-4xl mx-auto"
    >
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold gradient-text">Categories</h1>
          <p className="text-muted-foreground text-sm mt-1">Organise your products into groups</p>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          className="text-white font-semibold rounded-xl shadow-lg transition-all hover:scale-[1.02]"
          style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)', boxShadow: '0 4px 16px rgba(139,92,246,0.35)' }}
        >
          <Plus className="w-4 h-4 mr-2" /> Add Category
        </Button>
      </div>

      <div className="glass-card rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="p-14 flex justify-center text-muted-foreground">
            <Loader2 className="w-6 h-6 animate-spin text-violet-400" />
          </div>
        ) : categories?.length === 0 ? (
          <div className="p-14 text-center text-muted-foreground flex flex-col items-center">
            <Tags className="w-12 h-12 mb-3 opacity-20" />
            <p className="text-sm">No categories yet</p>
          </div>
        ) : (
          <ul className="divide-y divide-border/30">
            {categories?.map((cat, idx) => {
              const color = CATEGORY_COLORS[idx % CATEGORY_COLORS.length];
              return (
                <motion.li
                  key={cat.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-5 hover:bg-white/40 transition-colors flex items-center gap-4"
                >
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-md"
                    style={{ background: `${color}18`, border: `1.5px solid ${color}30` }}
                  >
                    <Hash className="w-4 h-4" style={{ color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground">{cat.name}</h3>
                    {cat.description && (
                      <p className="text-muted-foreground text-sm mt-0.5 truncate">{cat.description}</p>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap">
                    {new Date(cat.createdAt).toLocaleDateString()}
                  </div>
                </motion.li>
              );
            })}
          </ul>
        )}
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="rounded-2xl glass-card border-white/80">
          <DialogHeader>
            <DialogTitle className="font-display">Add Category</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Name</label>
              <Input {...form.register("name")} placeholder="Category Name" className="rounded-xl" />
              {form.formState.errors.name && (
                <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Description</label>
              <Input {...form.register("description")} placeholder="Optional description" className="rounded-xl" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" className="rounded-xl" onClick={() => setIsModalOpen(false)}>Cancel</Button>
              <Button
                type="submit"
                disabled={create.isPending}
                className="rounded-xl text-white"
                style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}
              >
                {create.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
