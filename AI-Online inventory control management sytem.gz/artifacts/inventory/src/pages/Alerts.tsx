import { useProducts } from "@/hooks/use-products";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Package, Loader2, ArrowRight, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Alerts() {
  const { data: products, isLoading } = useProducts({ lowStock: true });

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6 max-w-5xl mx-auto"
    >
      <div>
        <h1 className="text-3xl font-display font-bold flex items-center gap-3">
          <span className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(239,68,68,0.12)' }}>
            <AlertTriangle className="w-5 h-5 text-rose-500" />
          </span>
          <span style={{ background: 'linear-gradient(135deg, #ef4444, #f97316)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
            Low Stock Alerts
          </span>
        </h1>
        <p className="text-muted-foreground mt-2 text-sm ml-[52px]">
          Products that have fallen below their minimum required stock levels.
        </p>
      </div>

      <div className="glass-card rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="p-14 flex justify-center text-muted-foreground">
            <Loader2 className="w-6 h-6 animate-spin text-rose-400" />
          </div>
        ) : products?.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-16 text-center flex flex-col items-center"
            style={{ background: 'linear-gradient(135deg, rgba(16,185,129,0.05), rgba(5,150,105,0.03))' }}
          >
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-lg"
              style={{ background: 'linear-gradient(135deg, #10b981, #059669)', boxShadow: '0 8px 24px rgba(16,185,129,0.3)' }}
            >
              <CheckCircle2 className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-display font-bold text-emerald-700 mb-1">All Clear!</h3>
            <p className="text-emerald-600/70 text-sm">No products are currently running low on stock.</p>
          </motion.div>
        ) : (
          <ul className="divide-y divide-border/30">
            {products?.map((product, idx) => {
              const deficit = product.minQuantity - product.quantity;
              const isOutOfStock = product.quantity === 0;
              return (
                <motion.li
                  key={product.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.06 }}
                  className="p-5 sm:px-7 hover:bg-rose-50/30 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-5"
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 shadow-md"
                      style={{
                        background: isOutOfStock ? 'linear-gradient(135deg, #ef4444, #dc2626)' : 'rgba(239,68,68,0.1)',
                        boxShadow: isOutOfStock ? '0 4px 12px rgba(239,68,68,0.35)' : 'none',
                      }}
                    >
                      <AlertTriangle
                        className="w-5 h-5"
                        style={{ color: isOutOfStock ? 'white' : '#ef4444' }}
                      />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{product.name}</h3>
                      <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2 flex-wrap">
                        <span className="font-mono bg-muted/60 px-2 py-0.5 rounded-md">{product.sku}</span>
                        {product.categoryName && (
                          <span className="text-muted-foreground">{product.categoryName}</span>
                        )}
                        {isOutOfStock && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold text-white"
                            style={{ background: 'linear-gradient(135deg, #ef4444, #dc2626)' }}>
                            OUT OF STOCK
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 sm:gap-8 ml-[60px] sm:ml-0">
                    <div className="text-center">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Current</p>
                      <p className="text-2xl font-display font-bold text-rose-500">{product.quantity}</p>
                    </div>
                    <div className="text-center px-5 border-x border-border/40">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Minimum</p>
                      <p className="text-2xl font-display font-bold text-foreground">{product.minQuantity}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Deficit</p>
                      <p className="text-2xl font-display font-bold text-orange-500">-{deficit}</p>
                    </div>
                    <Link href="/movements">
                      <Button
                        size="sm"
                        className="rounded-xl text-white text-xs"
                        style={{ background: 'linear-gradient(135deg, #ef4444, #dc2626)', boxShadow: '0 4px 12px rgba(239,68,68,0.3)' }}
                      >
                        Restock <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                      </Button>
                    </Link>
                  </div>
                </motion.li>
              );
            })}
          </ul>
        )}
      </div>
    </motion.div>
  );
}
