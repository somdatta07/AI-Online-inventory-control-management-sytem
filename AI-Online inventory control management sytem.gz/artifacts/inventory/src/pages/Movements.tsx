import { useState } from "react";
import { useMovements, useMovementMutations } from "@/hooks/use-movements";
import { useProducts } from "@/hooks/use-products";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, ArrowRightLeft, ArrowUpRight, ArrowDownRight, RefreshCcw, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { motion } from "framer-motion";

const movementSchema = z.object({
  productId: z.coerce.number().min(1, "Product is required"),
  type: z.enum(["in", "out", "adjustment"]),
  quantity: z.coerce.number().min(1, "Must be > 0"),
  note: z.string().optional(),
});

const typeConfig = {
  in: { label: "Stock In", icon: ArrowDownRight, color: "#10b981", bg: "rgba(16,185,129,0.1)", sign: "+" },
  out: { label: "Stock Out", icon: ArrowUpRight, color: "#ef4444", bg: "rgba(239,68,68,0.1)", sign: "-" },
  adjustment: { label: "Adjustment", icon: RefreshCcw, color: "#6366f1", bg: "rgba(99,102,241,0.1)", sign: "±" },
};

export default function Movements() {
  const { data: movements, isLoading } = useMovements({ limit: 100 });
  const { data: products } = useProducts();
  const { create } = useMovementMutations();
  const { toast } = useToast();

  const [isModalOpen, setIsModalOpen] = useState(false);

  const form = useForm<z.infer<typeof movementSchema>>({
    resolver: zodResolver(movementSchema),
    defaultValues: { productId: 0, type: "in", quantity: 1, note: "" },
  });

  const onSubmit = async (data: z.infer<typeof movementSchema>) => {
    try {
      await create.mutateAsync({ data });
      toast({ title: "Movement recorded successfully" });
      setIsModalOpen(false);
      form.reset();
    } catch {
      toast({ title: "Failed to record movement", variant: "destructive" });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold gradient-text">Stock Movements</h1>
          <p className="text-muted-foreground text-sm mt-1">Full history of all inventory changes</p>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          className="text-white font-semibold rounded-xl shadow-lg transition-all hover:scale-[1.02]"
          style={{ background: 'linear-gradient(135deg, #10b981, #059669)', boxShadow: '0 4px 16px rgba(16,185,129,0.3)' }}
        >
          <ArrowRightLeft className="w-4 h-4 mr-2" /> Record Movement
        </Button>
      </div>

      <div className="glass-card rounded-2xl overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-border/40" style={{ background: 'rgba(99,102,241,0.04)' }}>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Type</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Product</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Qty</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Note</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {isLoading ? (
              <tr>
                <td colSpan={5} className="px-4 py-14 text-center text-muted-foreground">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-400" />
                  <p className="text-sm">Loading history…</p>
                </td>
              </tr>
            ) : movements?.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-14 text-center text-muted-foreground">
                  <ArrowRightLeft className="w-10 h-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">No stock movements recorded yet</p>
                </td>
              </tr>
            ) : (
              movements?.map((m, idx) => {
                const cfg = typeConfig[m.type as keyof typeof typeConfig] || typeConfig.adjustment;
                const Icon = cfg.icon;
                return (
                  <motion.tr
                    key={m.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: idx * 0.02 }}
                    className="hover:bg-indigo-50/30 transition-colors"
                  >
                    <td className="px-4 py-3.5 whitespace-nowrap text-muted-foreground text-xs">
                      {format(new Date(m.createdAt), "MMM d, yyyy HH:mm")}
                    </td>
                    <td className="px-4 py-3.5">
                      <span
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold"
                        style={{ background: cfg.bg, color: cfg.color }}
                      >
                        <Icon className="w-3 h-3" />
                        {cfg.label}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 font-medium text-foreground">{m.productName}</td>
                    <td className="px-4 py-3.5 text-right font-bold text-base" style={{ color: cfg.color }}>
                      {cfg.sign}{m.quantity}
                    </td>
                    <td className="px-4 py-3.5 text-muted-foreground italic text-xs truncate max-w-[180px]">
                      {m.note || "—"}
                    </td>
                  </motion.tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="rounded-2xl glass-card border-white/80">
          <DialogHeader>
            <DialogTitle className="font-display">Record Stock Movement</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Product</label>
              <select
                {...form.register("productId")}
                className="flex h-10 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value={0}>Select Product</option>
                {products?.map(p => (
                  <option key={p.id} value={p.id}>{p.name} (Stock: {p.quantity} {p.unit})</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Movement Type</label>
                <select
                  {...form.register("type")}
                  className="flex h-10 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="in">Stock In (Receive)</option>
                  <option value="out">Stock Out (Ship/Use)</option>
                  <option value="adjustment">Adjustment (Audit)</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Quantity Change</label>
                <Input type="number" {...form.register("quantity")} placeholder="Amount" className="rounded-xl" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium">Note / Reason (Optional)</label>
              <Input {...form.register("note")} placeholder="e.g. Received PO-1234" className="rounded-xl" />
            </div>

            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" className="rounded-xl" onClick={() => setIsModalOpen(false)}>Cancel</Button>
              <Button
                type="submit"
                disabled={create.isPending}
                className="rounded-xl text-white"
                style={{ background: 'linear-gradient(135deg, #10b981, #059669)' }}
              >
                {create.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Record
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
