import { useDashboardStats } from "@/hooks/use-dashboard";
import { useProducts } from "@/hooks/use-products";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
} from "recharts";
import {
  Package,
  AlertTriangle,
  DollarSign,
  Activity,
  ArrowRight,
  Bot,
  TrendingUp,
} from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const statCards = [
  {
    key: "totalProducts",
    title: "Total Products",
    icon: Package,
    gradient: "linear-gradient(135deg, #6366f1, #8b5cf6)",
    glow: "rgba(99,102,241,0.25)",
    bg: "rgba(99,102,241,0.08)",
    iconColor: "#6366f1",
  },
  {
    key: "totalInventoryValue",
    title: "Inventory Value",
    icon: DollarSign,
    gradient: "linear-gradient(135deg, #10b981, #059669)",
    glow: "rgba(16,185,129,0.22)",
    bg: "rgba(16,185,129,0.08)",
    iconColor: "#10b981",
    prefix: "$",
  },
  {
    key: "lowStockCount",
    title: "Low Stock Items",
    icon: AlertTriangle,
    gradient: "linear-gradient(135deg, #f59e0b, #d97706)",
    glow: "rgba(245,158,11,0.22)",
    bg: "rgba(245,158,11,0.08)",
    iconColor: "#f59e0b",
  },
  {
    key: "outOfStockCount",
    title: "Out of Stock",
    icon: Activity,
    gradient: "linear-gradient(135deg, #ef4444, #dc2626)",
    glow: "rgba(239,68,68,0.22)",
    bg: "rgba(239,68,68,0.08)",
    iconColor: "#ef4444",
  },
];

function StatCard({ card, value, isLoading, delay }: any) {
  const Icon = card.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay, ease: [0.23, 1, 0.32, 1] }}
      className="glass-card-hover rounded-2xl p-5 flex items-center gap-4"
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg"
        style={{ background: card.gradient, boxShadow: `0 6px 20px ${card.glow}` }}
      >
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{card.title}</p>
        <h3 className="text-2xl font-display font-bold text-foreground mt-0.5 leading-none">
          {isLoading ? (
            <Skeleton className="h-7 w-24 mt-1" />
          ) : (
            card.prefix
              ? `${card.prefix}${typeof value === "number" ? value.toLocaleString(undefined, { minimumFractionDigits: 2 }) : value}`
              : value ?? 0
          )}
        </h3>
      </div>
      <div className="ml-auto">
        <TrendingUp className="w-4 h-4 opacity-20" />
      </div>
    </motion.div>
  );
}

const BAR_COLORS = ["#6366f1", "#8b5cf6", "#a78bfa", "#c4b5fd", "#ddd6fe"];

export default function Dashboard() {
  const { data: stats, isLoading: isStatsLoading } = useDashboardStats();
  const { data: products, isLoading: isProductsLoading } = useProducts();

  const chartData = products
    ? [...products]
        .map(p => ({ name: p.name.length > 14 ? p.name.slice(0, 14) + "…" : p.name, value: Math.round(p.quantity * p.unitPrice) }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 5)
    : [];

  return (
    <div className="space-y-7 pb-12">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col md:flex-row md:items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-display font-bold gradient-text">Inventory Overview</h1>
          <p className="text-muted-foreground mt-1 text-sm">Track products, stock levels, and daily movements.</p>
        </div>
        <Link
          href="/movements"
          className="inline-flex items-center justify-center px-4 py-2.5 rounded-xl font-semibold text-sm text-white shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98]"
          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', boxShadow: '0 4px 16px rgba(99,102,241,0.35)' }}
        >
          View Movements <ArrowRight className="w-4 h-4 ml-2" />
        </Link>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <StatCard
            key={card.key}
            card={card}
            value={stats?.[card.key as keyof typeof stats]}
            isLoading={isStatsLoading}
            delay={i * 0.08}
          />
        ))}
      </div>

      {/* Chart + AI Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Bar Chart */}
        <motion.div
          className="lg:col-span-2"
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.35 }}
        >
          <div className="glass-card rounded-2xl p-6 h-full flex flex-col">
            <h3 className="font-display font-semibold text-base mb-1 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: 'rgba(99,102,241,0.12)' }}>
                <DollarSign className="w-3.5 h-3.5 text-indigo-500" />
              </span>
              Top Products by Value
            </h3>
            <p className="text-xs text-muted-foreground mb-5">Highest inventory value items</p>
            <div className="flex-1 min-h-[280px]">
              {isProductsLoading ? (
                <Skeleton className="w-full h-full rounded-xl" />
              ) : chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#6366f1" stopOpacity={1} />
                        <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.75} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(100,100,180,0.1)" />
                    <XAxis
                      dataKey="name"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      dy={10}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      tickFormatter={(val) => `$${val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val}`}
                    />
                    <RechartsTooltip
                      cursor={{ fill: 'rgba(99,102,241,0.06)', radius: 8 }}
                      contentStyle={{
                        borderRadius: '12px',
                        border: '1px solid rgba(255,255,255,0.8)',
                        background: 'rgba(255,255,255,0.92)',
                        backdropFilter: 'blur(10px)',
                        boxShadow: '0 8px 24px rgba(0,0,0,0.1)',
                        fontSize: '13px',
                      }}
                      formatter={(val: number) => [`$${val.toLocaleString()}`, 'Value']}
                    />
                    <Bar dataKey="value" radius={[8, 8, 0, 0]} fill="url(#barGrad)" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                  <Package className="w-12 h-12 mb-3 opacity-20" />
                  <p className="text-sm">No products to display</p>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {/* AI Panel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.45 }}
        >
          <div
            className="rounded-2xl p-6 h-full flex flex-col overflow-hidden relative shadow-xl"
            style={{
              background: 'linear-gradient(145deg, #1e1b4b 0%, #312e81 40%, #4c1d95 100%)',
              boxShadow: '0 12px 40px rgba(99,102,241,0.35)',
            }}
          >
            {/* Background bot icon */}
            <div className="absolute top-3 right-3 opacity-[0.08] pointer-events-none">
              <Bot className="w-28 h-28 text-white" />
            </div>
            {/* Glow orb */}
            <div className="absolute top-[-20px] right-[-20px] w-40 h-40 rounded-full opacity-20 pointer-events-none"
              style={{ background: 'radial-gradient(circle, #a78bfa, transparent)' }} />

            <div className="relative z-10">
              <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-4 border border-white/20">
                <Bot className="w-5 h-5 text-violet-200" />
              </div>
              <h3 className="font-display font-bold text-white text-lg mb-1.5">AI Insights Ready</h3>
              <p className="text-violet-200/80 text-xs mb-5 leading-relaxed">
                Intelligent recommendations on reordering, stock distribution, and pricing — powered by your data.
              </p>
            </div>

            <div className="space-y-2.5 mb-6 relative z-10">
              {[
                "Which products should I restock?",
                "Items taking up too much capital?",
              ].map((prompt) => (
                <div key={prompt} className="rounded-xl p-3 border border-white/10 bg-white/[0.07] backdrop-blur-sm">
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-violet-300/60 mb-1">Suggestion</p>
                  <p className="text-sm text-white/90">"{prompt}"</p>
                </div>
              ))}
            </div>

            <div className="mt-auto relative z-10">
              <Link
                href="/ai-assistant"
                className="w-full inline-flex justify-center items-center py-2.5 px-4 bg-white font-semibold text-sm rounded-xl hover:bg-white/90 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg"
                style={{ color: '#312e81' }}
              >
                Launch AI Assistant
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
