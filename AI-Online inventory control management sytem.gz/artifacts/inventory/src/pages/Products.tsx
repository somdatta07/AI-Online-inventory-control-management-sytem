import { useState } from "react";
import { useProducts, useProductMutations } from "@/hooks/use-products";
import { useCategories } from "@/hooks/use-categories";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Search, Plus, Edit2, Trash2, Tag, Loader2, Package } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@workspace/api-client-react";
import { motion } from "framer-motion";

const productSchema = z.object({
  name: z.string().min(2, "Name is required"),
  sku: z.string().min(2, "SKU is required"),
  description: z.string().optional(),
  categoryId: z.coerce.number().optional().nullable(),
  quantity: z.coerce.number().min(0, "Must be >= 0"),
  minQuantity: z.coerce.number().min(0, "Must be >= 0"),
  unitPrice: z.coerce.number().min(0, "Must be >= 0"),
  unit: z.string().min(1, "Unit required"),
});

type ProductFormData = z.infer<typeof productSchema>;

export default function Products() {
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState<number | "">("");

  const { data: products, isLoading } = useProducts({
    search: search || undefined,
    categoryId: categoryId === "" ? undefined : categoryId,
  });
  const { data: categories } = useCategories();
  const { create, update, remove } = useProductMutations();
  const { toast } = useToast();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "", sku: "", description: "", quantity: 0, minQuantity: 0, unitPrice: 0, unit: "pcs", categoryId: null,
    },
  });

  const openAddModal = () => {
    setEditingProduct(null);
    form.reset({ name: "", sku: "", description: "", quantity: 0, minQuantity: 5, unitPrice: 0, unit: "pcs", categoryId: null });
    setIsModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    form.reset({
      name: product.name, sku: product.sku, description: product.description || "",
      quantity: product.quantity, minQuantity: product.minQuantity, unitPrice: product.unitPrice,
      unit: product.unit, categoryId: product.categoryId || null,
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this product?")) return;
    try {
      await remove.mutateAsync({ id });
      toast({ title: "Product deleted" });
    } catch {
      toast({ title: "Failed to delete product", variant: "destructive" });
    }
  };

  const onSubmit = async (data: ProductFormData) => {
    try {
      if (editingProduct) {
        await update.mutateAsync({ id: editingProduct.id, data: { ...data, isActive: true } });
        toast({ title: "Product updated successfully" });
      } else {
        await create.mutateAsync({ data });
        toast({ title: "Product created successfully" });
      }
      setIsModalOpen(false);
    } catch {
      toast({ title: "Operation failed", variant: "destructive" });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold gradient-text">Products</h1>
          <p className="text-muted-foreground text-sm mt-1">Manage your product catalog and inventory</p>
        </div>
        <Button
          onClick={openAddModal}
          className="text-white font-semibold shadow-lg rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98]"
          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', boxShadow: '0 4px 16px rgba(99,102,241,0.35)' }}
        >
          <Plus className="w-4 h-4 mr-2" /> Add Product
        </Button>
      </div>

      <div className="glass-card rounded-2xl p-5">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search products..."
              className="pl-9 rounded-xl border-border/60 bg-white/60 focus-visible:ring-indigo-300"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select
            className="flex h-10 w-full sm:w-56 rounded-xl border border-border/60 bg-white/60 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-300"
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value ? Number(e.target.value) : "")}
          >
            <option value="">All Categories</option>
            {categories?.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        {/* Table */}
        <div className="rounded-xl overflow-hidden border border-border/40">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b border-border/40" style={{ background: 'rgba(99,102,241,0.04)' }}>
                <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Product</th>
                <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Category</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Price</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Stock</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/30">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-4 py-14 text-center text-muted-foreground">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-400" />
                    <p className="text-sm">Loading products…</p>
                  </td>
                </tr>
              ) : products?.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-14 text-center text-muted-foreground">
                    <Package className="w-10 h-10 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No products found</p>
                  </td>
                </tr>
              ) : (
                products?.map((product, idx) => {
                  const isOutOfStock = product.quantity === 0;
                  const isLowStock = product.quantity <= product.minQuantity && !isOutOfStock;
                  return (
                    <motion.tr
                      key={product.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: idx * 0.03 }}
                      className="hover:bg-indigo-50/40 transition-colors group"
                    >
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-foreground text-sm">{product.name}</div>
                        <div className="text-[11px] text-muted-foreground mt-0.5 font-mono">{product.sku}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        {product.categoryName ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-1 rounded-lg"
                            style={{ background: 'rgba(139,92,246,0.1)', color: '#7c3aed' }}>
                            <Tag className="w-3 h-3" />
                            {product.categoryName}
                          </span>
                        ) : <span className="text-muted-foreground text-xs">—</span>}
                      </td>
                      <td className="px-4 py-3.5 text-right font-semibold text-sm">
                        ${product.unitPrice.toFixed(2)}
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <span className="font-bold text-foreground">{product.quantity}</span>
                        <span className="text-xs text-muted-foreground ml-1">{product.unit}</span>
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        {isOutOfStock ? (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold"
                            style={{ background: 'rgba(239,68,68,0.1)', color: '#dc2626' }}>
                            Out of Stock
                          </span>
                        ) : isLowStock ? (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold"
                            style={{ background: 'rgba(245,158,11,0.1)', color: '#d97706' }}>
                            Low Stock
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold"
                            style={{ background: 'rgba(16,185,129,0.1)', color: '#059669' }}>
                            In Stock
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <div className="flex justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => openEditModal(product)}
                            className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:bg-indigo-100"
                            style={{ color: '#6366f1' }}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(product.id)}
                            className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:bg-red-100"
                            style={{ color: '#ef4444' }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dialog */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl glass-card border-white/80">
          <DialogHeader>
            <DialogTitle className="font-display">{editingProduct ? "Edit Product" : "Add Product"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-3">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Name</label>
                <Input {...form.register("name")} placeholder="Product Name" className="rounded-xl" />
                {form.formState.errors.name && <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>}
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">SKU</label>
                <Input {...form.register("sku")} placeholder="SKU-123" className="rounded-xl" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium">Category</label>
              <select
                {...form.register("categoryId")}
                className="flex h-10 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="">No Category</option>
                {categories?.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Quantity</label>
                <Input type="number" {...form.register("quantity")} className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Min Qty</label>
                <Input type="number" {...form.register("minQuantity")} className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Unit Price</label>
                <Input type="number" step="0.01" {...form.register("unitPrice")} className="rounded-xl" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium">Unit Label</label>
              <Input {...form.register("unit")} placeholder="e.g. pcs, kg, boxes" className="rounded-xl" />
            </div>

            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" className="rounded-xl" onClick={() => setIsModalOpen(false)}>Cancel</Button>
              <Button
                type="submit"
                disabled={create.isPending || update.isPending}
                className="rounded-xl text-white"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
              >
                {(create.isPending || update.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingProduct ? "Save Changes" : "Create Product"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
