import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Package,
  Tags,
  ArrowRightLeft,
  AlertTriangle,
  Bot,
  Menu,
  X,
  Boxes,
  ChevronRight,
  LogOut,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@workspace/replit-auth-web";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard", color: "#6366f1" },
  { href: "/products", icon: Package, label: "Products", color: "#06b6d4" },
  { href: "/categories", icon: Tags, label: "Categories", color: "#8b5cf6" },
  { href: "/movements", icon: ArrowRightLeft, label: "Stock Movements", color: "#10b981" },
  { href: "/alerts", icon: AlertTriangle, label: "Low Stock Alerts", color: "#f59e0b" },
  { href: "/ai-assistant", icon: Bot, label: "AI Insights", color: "#ec4899" },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, logout } = useAuth();

  const currentNav = navItems.find(i => i.href === location);
  const displayName = user?.firstName
    ? `${user.firstName}${user.lastName ? " " + user.lastName : ""}`
    : (user?.email ?? "User");
  const initials = displayName.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div className="min-h-screen flex" style={{ background: 'transparent' }}>
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
            onClick={() => setMobileOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 sidebar-glass text-sidebar-foreground transition-transform duration-300 md:relative md:translate-x-0 flex flex-col overflow-hidden",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Ambient glow blobs */}
        <div className="absolute top-[-60px] right-[-40px] w-48 h-48 rounded-full opacity-[0.07] pointer-events-none"
          style={{ background: 'radial-gradient(circle, #6366f1, transparent)' }} />
        <div className="absolute bottom-[80px] left-[-30px] w-40 h-40 rounded-full opacity-[0.05] pointer-events-none"
          style={{ background: 'radial-gradient(circle, #8b5cf6, transparent)' }} />

        {/* Logo */}
        <div className="h-16 flex items-center px-5 border-b border-white/[0.06] relative">
          <div className="w-8 h-8 rounded-xl gradient-bg-primary flex items-center justify-center mr-3 shadow-lg shadow-indigo-500/30 flex-shrink-0">
            <Boxes className="w-4 h-4 text-white" />
          </div>
          <h1 className="text-lg font-display font-bold tracking-wide text-white">
            Astra<span style={{ color: '#a5b4fc' }}>Flow</span>
          </h1>
          <button
            className="ml-auto md:hidden text-white/50 hover:text-white transition-colors"
            onClick={() => setMobileOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-5 px-3 space-y-0.5 overflow-y-auto">
          <p className="text-[10px] font-semibold uppercase tracking-widest text-white/25 px-3 pb-2 pt-1">Navigation</p>
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group relative",
                  isActive
                    ? "text-white"
                    : "text-white/50 hover:text-white/90 hover:bg-white/[0.06]"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute inset-0 rounded-xl"
                    style={{ background: `linear-gradient(135deg, ${item.color}28, ${item.color}14)`, border: `1px solid ${item.color}30` }}
                    transition={{ type: "spring", stiffness: 380, damping: 36 }}
                  />
                )}
                <div
                  className={cn(
                    "w-7 h-7 rounded-lg flex items-center justify-center mr-3 flex-shrink-0 transition-all duration-200 relative z-10",
                    isActive ? "shadow-md" : "bg-white/[0.05] group-hover:bg-white/[0.08]"
                  )}
                  style={isActive ? { background: `${item.color}30`, boxShadow: `0 2px 8px ${item.color}40` } : {}}
                >
                  <item.icon
                    className="w-3.5 h-3.5"
                    style={{ color: isActive ? item.color : undefined }}
                  />
                </div>
                <span className="relative z-10 flex-1">{item.label}</span>
                {isActive && (
                  <ChevronRight className="w-3.5 h-3.5 relative z-10 opacity-50" style={{ color: item.color }} />
                )}
              </Link>
            );
          })}
        </nav>

        {/* User Footer */}
        <div className="p-3 border-t border-white/[0.06] space-y-1">
          <div className="flex items-center px-3 py-2.5 rounded-xl bg-white/[0.04]">
            <div className="w-8 h-8 rounded-full gradient-bg-primary flex items-center justify-center font-bold text-white text-xs mr-3 shadow-lg shadow-indigo-500/30 flex-shrink-0">
              {initials}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-white leading-none truncate">{displayName}</p>
              {user?.email && (
                <p className="text-[11px] text-white/40 mt-0.5 truncate">{user.email}</p>
              )}
            </div>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-white/50 hover:text-white hover:bg-white/[0.06] transition-all text-sm font-medium"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Header */}
        <header className="h-14 flex-shrink-0 flex items-center px-4 md:px-6 z-10 border-b"
          style={{
            background: 'rgba(255,255,255,0.75)',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            borderColor: 'rgba(200, 200, 240, 0.35)',
            boxShadow: '0 1px 0 rgba(200,200,240,0.2)',
          }}>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden mr-3 h-8 w-8"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-2">
            {currentNav && (
              <div
                className="w-6 h-6 rounded-md flex items-center justify-center"
                style={{ background: `${currentNav.color}18` }}
              >
                <currentNav.icon className="w-3.5 h-3.5" style={{ color: currentNav.color }} />
              </div>
            )}
            <span className="font-semibold text-sm text-foreground/80">
              {currentNav?.label || "Overview"}
            </span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" />
            <span className="text-xs text-muted-foreground font-medium">Live</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-7">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
