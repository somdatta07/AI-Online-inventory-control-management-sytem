import {
  useGetDashboardStats,
  useGetAiInsights,
  useListAiHistory,
  useDeleteAiHistoryEntry,
  useClearAiHistory,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useDashboardStats() {
  return useGetDashboardStats();
}

export function useAiAssistant() {
  return useGetAiInsights();
}

export function useAiHistory(limit?: number) {
  return useListAiHistory({ limit });
}

export function useAiHistoryMutations() {
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/ai/history"] });
  };

  const deleteEntry = useDeleteAiHistoryEntry({ mutation: { onSuccess: invalidate } });
  const clearAll = useClearAiHistory({ mutation: { onSuccess: invalidate } });

  return { deleteEntry, clearAll };
}
