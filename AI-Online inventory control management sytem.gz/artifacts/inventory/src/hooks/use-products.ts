import { useQueryClient } from "@tanstack/react-query";
import {
  useListProducts,
  useCreateProduct,
  useUpdateProduct,
  useDeleteProduct,
  getListProductsQueryKey,
  type ListProductsParams,
} from "@workspace/api-client-react";

export function useProducts(params?: ListProductsParams) {
  return useListProducts(params);
}

export function useProductMutations() {
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
  };

  const create = useCreateProduct({ mutation: { onSuccess: invalidate } });
  const update = useUpdateProduct({ mutation: { onSuccess: invalidate } });
  const remove = useDeleteProduct({ mutation: { onSuccess: invalidate } });

  return { create, update, remove };
}
