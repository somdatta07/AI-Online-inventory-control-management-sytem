import { useQueryClient } from "@tanstack/react-query";
import {
  useListCategories,
  useCreateCategory,
} from "@workspace/api-client-react";

export function useCategories() {
  return useListCategories();
}

export function useCategoryMutations() {
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
  };

  const create = useCreateCategory({ mutation: { onSuccess: invalidate } });

  return { create };
}
