import { useQueryClient } from "@tanstack/react-query";
import {
  useListMovements,
  useCreateMovement,
  type ListMovementsParams,
} from "@workspace/api-client-react";

export function useMovements(params?: ListMovementsParams) {
  return useListMovements(params);
}

export function useMovementMutations() {
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/movements"] });
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
  };

  const create = useCreateMovement({ mutation: { onSuccess: invalidate } });

  return { create };
}
