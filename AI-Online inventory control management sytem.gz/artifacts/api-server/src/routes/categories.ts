import { Router } from "express";
import { db, categoriesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateCategoryBody } from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const categories = await db.select().from(categoriesTable).orderBy(categoriesTable.name);
  const result = categories.map(c => ({
    id: c.id,
    name: c.name,
    description: c.description ?? null,
    createdAt: c.createdAt.toISOString(),
  }));
  res.json(result);
});

router.post("/", async (req, res) => {
  const body = CreateCategoryBody.parse(req.body);
  const [created] = await db.insert(categoriesTable).values(body).returning();
  res.status(201).json({
    id: created.id,
    name: created.name,
    description: created.description ?? null,
    createdAt: created.createdAt.toISOString(),
  });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(categoriesTable).where(eq(categoriesTable.id, id));
  res.status(204).end();
});

export default router;
