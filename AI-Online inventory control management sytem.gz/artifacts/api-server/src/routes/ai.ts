import { Router } from "express";
import { db, productsTable, categoriesTable, aiHistoryTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { GetAiInsightsBody, ListAiHistoryQueryParams, DeleteAiHistoryEntryParams } from "@workspace/api-zod";
import OpenAI from "openai";

const router = Router();

const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

router.get("/history", async (req, res) => {
  const query = ListAiHistoryQueryParams.parse(req.query);
  const rows = await db
    .select()
    .from(aiHistoryTable)
    .orderBy(desc(aiHistoryTable.createdAt))
    .limit(query.limit ?? 50);

  res.json(rows.map(r => ({
    id: r.id,
    query: r.query,
    insight: r.insight,
    recommendations: r.recommendations as string[],
    createdAt: r.createdAt.toISOString(),
  })));
});

router.delete("/history", async (_req, res) => {
  await db.delete(aiHistoryTable);
  res.status(204).end();
});

router.delete("/history/:id", async (req, res) => {
  const { id } = DeleteAiHistoryEntryParams.parse({ id: parseInt(req.params.id) });
  await db.delete(aiHistoryTable).where(eq(aiHistoryTable.id, id));
  res.status(204).end();
});

router.post("/insights", async (req, res) => {
  const { query } = GetAiInsightsBody.parse(req.body);

  // Gather inventory context
  const products = await db
    .select({
      name: productsTable.name,
      sku: productsTable.sku,
      quantity: productsTable.quantity,
      minQuantity: productsTable.minQuantity,
      unitPrice: productsTable.unitPrice,
      unit: productsTable.unit,
      isActive: productsTable.isActive,
      categoryName: categoriesTable.name,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.isActive, true));

  const inventorySummary = products.map(p => ({
    name: p.name,
    sku: p.sku,
    category: p.categoryName ?? "Uncategorized",
    quantity: p.quantity,
    minQuantity: p.minQuantity,
    unitPrice: parseFloat(p.unitPrice),
    unit: p.unit,
    isLowStock: p.quantity <= p.minQuantity,
    isOutOfStock: p.quantity === 0,
  }));

  const systemPrompt = `You are an AI inventory management assistant. You have access to the current inventory data and help managers make smart decisions about their stock.

Current Inventory Summary:
${JSON.stringify(inventorySummary, null, 2)}

Provide concise, actionable insights. Format your response as JSON with two fields:
- "insight": a 2-3 sentence overall insight
- "recommendations": an array of 3-5 specific actionable recommendations as strings

Always respond with valid JSON only, no markdown.`;

  const completion = await openai.chat.completions.create({
    model: "gpt-5.2",
    max_completion_tokens: 1024,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: query },
    ],
  });

  const responseText = completion.choices[0]?.message?.content ?? '{"insight":"Unable to generate insights.","recommendations":[]}';

  let parsed: { insight: string; recommendations: string[] };
  try {
    parsed = JSON.parse(responseText);
  } catch {
    parsed = { insight: responseText, recommendations: [] };
  }

  // Save to history
  const [saved] = await db.insert(aiHistoryTable).values({
    query,
    insight: parsed.insight,
    recommendations: parsed.recommendations,
  }).returning();

  res.json({
    ...parsed,
    id: saved.id,
    createdAt: saved.createdAt.toISOString(),
  });
});

export default router;
