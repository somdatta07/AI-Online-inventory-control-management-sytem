import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import categoriesRouter from "./categories";
import productsRouter from "./products";
import movementsRouter from "./movements";
import aiRouter from "./ai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use("/categories", categoriesRouter);
router.use("/products", productsRouter);
router.use("/dashboard/stats", (req, res, next) => {
  req.url = "/stats";
  productsRouter(req, res, next);
});
router.use("/movements", movementsRouter);
router.use("/ai", aiRouter);

export default router;
