import { Router } from "express";
import { db, movementsTable, productsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { CreateMovementBody, ListMovementsQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const query = ListMovementsQueryParams.parse(req.query);

  const rows = await db
    .select({
      id: movementsTable.id,
      productId: movementsTable.productId,
      productName: productsTable.name,
      type: movementsTable.type,
      quantity: movementsTable.quantity,
      note: movementsTable.note,
      createdAt: movementsTable.createdAt,
    })
    .from(movementsTable)
    .leftJoin(productsTable, eq(movementsTable.productId, productsTable.id))
    .orderBy(desc(movementsTable.createdAt))
    .limit(query.limit ?? 100);

  const filtered = query.productId
    ? rows.filter(r => r.productId === query.productId)
    : rows;

  res.json(filtered.map(r => ({
    id: r.id,
    productId: r.productId,
    productName: r.productName ?? "Unknown",
    type: r.type,
    quantity: r.quantity,
    note: r.note ?? null,
    createdAt: r.createdAt.toISOString(),
  })));
});

router.post("/", async (req, res) => {
  const body = CreateMovementBody.parse(req.body);

  const product = await db.select().from(productsTable).where(eq(productsTable.id, body.productId)).then(r => r[0]);
  if (!product) {
    return res.status(404).json({ error: "Product not found" });
  }

  // Update product quantity
  let newQty = product.quantity;
  if (body.type === "in") {
    newQty += body.quantity;
  } else if (body.type === "out") {
    newQty = Math.max(0, newQty - body.quantity);
  } else if (body.type === "adjustment") {
    newQty = body.quantity;
  }

  await db.update(productsTable)
    .set({ quantity: newQty, updatedAt: new Date() })
    .where(eq(productsTable.id, body.productId));

  const [movement] = await db.insert(movementsTable).values({
    productId: body.productId,
    type: body.type,
    quantity: body.quantity,
    note: body.note ?? null,
  }).returning();

  res.status(201).json({
    id: movement.id,
    productId: movement.productId,
    productName: product.name,
    type: movement.type,
    quantity: movement.quantity,
    note: movement.note ?? null,
    createdAt: movement.createdAt.toISOString(),
  });
});

export default router;
