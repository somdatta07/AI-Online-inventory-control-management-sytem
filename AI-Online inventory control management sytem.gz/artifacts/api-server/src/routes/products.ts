import { Router } from "express";
import { db, productsTable, categoriesTable, movementsTable } from "@workspace/db";
import { eq, lt, lte, sql, desc, ilike, and } from "drizzle-orm";
import { CreateProductBody, UpdateProductBody, ListProductsQueryParams } from "@workspace/api-zod";

const router = Router();

function formatProduct(p: any, categoryName: string | null) {
  return {
    id: p.id,
    name: p.name,
    sku: p.sku,
    description: p.description ?? null,
    categoryId: p.categoryId ?? null,
    categoryName: categoryName ?? null,
    quantity: p.quantity,
    minQuantity: p.minQuantity,
    unitPrice: parseFloat(p.unitPrice),
    unit: p.unit,
    isActive: p.isActive,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

router.get("/", async (req, res) => {
  const query = ListProductsQueryParams.parse(req.query);

  const rows = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      sku: productsTable.sku,
      description: productsTable.description,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      quantity: productsTable.quantity,
      minQuantity: productsTable.minQuantity,
      unitPrice: productsTable.unitPrice,
      unit: productsTable.unit,
      isActive: productsTable.isActive,
      createdAt: productsTable.createdAt,
      updatedAt: productsTable.updatedAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .orderBy(productsTable.name);

  let result = rows;

  if (query.categoryId) {
    result = result.filter(r => r.categoryId === query.categoryId);
  }
  if (query.lowStock) {
    result = result.filter(r => r.quantity <= r.minQuantity);
  }
  if (query.search) {
    const s = query.search.toLowerCase();
    result = result.filter(r => r.name.toLowerCase().includes(s) || r.sku.toLowerCase().includes(s));
  }

  res.json(result.map(r => formatProduct(r, r.categoryName ?? null)));
});

router.post("/", async (req, res) => {
  const body = CreateProductBody.parse(req.body);
  const [created] = await db.insert(productsTable).values({
    name: body.name,
    sku: body.sku,
    description: body.description ?? null,
    categoryId: body.categoryId ?? null,
    quantity: body.quantity,
    minQuantity: body.minQuantity,
    unitPrice: String(body.unitPrice),
    unit: body.unit,
  }).returning();

  let categoryName: string | null = null;
  if (created.categoryId) {
    const cat = await db.select().from(categoriesTable).where(eq(categoriesTable.id, created.categoryId)).then(r => r[0]);
    categoryName = cat?.name ?? null;
  }

  res.status(201).json(formatProduct(created, categoryName));
});

router.get("/stats", async (req, res) => {
  const products = await db
    .select({
      quantity: productsTable.quantity,
      minQuantity: productsTable.minQuantity,
      unitPrice: productsTable.unitPrice,
    })
    .from(productsTable)
    .where(eq(productsTable.isActive, true));

  const categories = await db.select().from(categoriesTable);

  const recentMoves = await db.select().from(movementsTable)
    .orderBy(desc(movementsTable.createdAt))
    .limit(7);

  const totalProducts = products.length;
  const lowStockCount = products.filter(p => p.quantity > 0 && p.quantity <= p.minQuantity).length;
  const outOfStockCount = products.filter(p => p.quantity === 0).length;
  const totalInventoryValue = products.reduce((sum, p) => sum + (p.quantity * parseFloat(p.unitPrice)), 0);

  res.json({
    totalProducts,
    lowStockCount,
    outOfStockCount,
    totalInventoryValue,
    totalCategories: categories.length,
    recentMovements: recentMoves.length,
  });
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const rows = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      sku: productsTable.sku,
      description: productsTable.description,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      quantity: productsTable.quantity,
      minQuantity: productsTable.minQuantity,
      unitPrice: productsTable.unitPrice,
      unit: productsTable.unit,
      isActive: productsTable.isActive,
      createdAt: productsTable.createdAt,
      updatedAt: productsTable.updatedAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.id, id));

  if (!rows[0]) return res.status(404).json({ error: "Not found" });
  res.json(formatProduct(rows[0], rows[0].categoryName ?? null));
});

router.put("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const body = UpdateProductBody.parse(req.body);

  const updateData: any = { updatedAt: new Date() };
  if (body.name !== undefined) updateData.name = body.name;
  if (body.sku !== undefined) updateData.sku = body.sku;
  if (body.description !== undefined) updateData.description = body.description;
  if (body.categoryId !== undefined) updateData.categoryId = body.categoryId;
  if (body.quantity !== undefined) updateData.quantity = body.quantity;
  if (body.minQuantity !== undefined) updateData.minQuantity = body.minQuantity;
  if (body.unitPrice !== undefined) updateData.unitPrice = String(body.unitPrice);
  if (body.unit !== undefined) updateData.unit = body.unit;
  if (body.isActive !== undefined) updateData.isActive = body.isActive;

  const [updated] = await db.update(productsTable)
    .set(updateData)
    .where(eq(productsTable.id, id))
    .returning();

  if (!updated) return res.status(404).json({ error: "Not found" });

  let categoryName: string | null = null;
  if (updated.categoryId) {
    const cat = await db.select().from(categoriesTable).where(eq(categoriesTable.id, updated.categoryId)).then(r => r[0]);
    categoryName = cat?.name ?? null;
  }

  res.json(formatProduct(updated, categoryName));
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(movementsTable).where(eq(movementsTable.productId, id));
  await db.delete(productsTable).where(eq(productsTable.id, id));
  res.status(204).end();
});

export default router;
