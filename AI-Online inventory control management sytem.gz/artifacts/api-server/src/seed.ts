import { db, categoriesTable, productsTable } from "@workspace/db";
import { count } from "drizzle-orm";
import { logger } from "./lib/logger";

const SEED_CATEGORIES = [
  { name: "Electronics", description: "Electronic components and devices" },
  { name: "Office Supplies", description: "Stationery and office essentials" },
  { name: "Furniture", description: "Office and warehouse furniture" },
  { name: "Safety Equipment", description: "PPE and safety gear" },
  { name: "Cleaning Supplies", description: "Cleaning and maintenance products" },
];

const SEED_PRODUCTS = [
  { name: 'Dell Monitor 27"', sku: "MON-DELL-27", description: "27 inch Full HD monitor", categoryIndex: 0, quantity: 45, minQuantity: 10, unitPrice: "299.99", unit: "pcs" },
  { name: "USB-C Hub 7-in-1", sku: "HUB-USBC-7", description: "Multi-port USB-C hub", categoryIndex: 0, quantity: 8, minQuantity: 15, unitPrice: "49.99", unit: "pcs" },
  { name: "Mechanical Keyboard", sku: "KBD-MECH-01", description: "Mechanical gaming keyboard", categoryIndex: 0, quantity: 23, minQuantity: 5, unitPrice: "89.99", unit: "pcs" },
  { name: "Wireless Mouse", sku: "MSE-WIRE-01", description: "Ergonomic wireless mouse", categoryIndex: 0, quantity: 0, minQuantity: 10, unitPrice: "39.99", unit: "pcs" },
  { name: "Webcam HD 1080p", sku: "CAM-HD-01", description: "Full HD USB webcam", categoryIndex: 0, quantity: 14, minQuantity: 5, unitPrice: "79.99", unit: "pcs" },
  { name: "A4 Paper Ream", sku: "PAP-A4-RM", description: "500 sheets A4 80gsm", categoryIndex: 1, quantity: 250, minQuantity: 50, unitPrice: "5.99", unit: "ream" },
  { name: "Ball Pens Blue (Box)", sku: "PEN-BLU-BX", description: "Box of 50 blue ballpoint pens", categoryIndex: 1, quantity: 30, minQuantity: 20, unitPrice: "8.50", unit: "box" },
  { name: "Sticky Notes 3x3", sku: "NOTE-3X3", description: "100 sheets sticky notes", categoryIndex: 1, quantity: 4, minQuantity: 25, unitPrice: "2.99", unit: "pack" },
  { name: "Whiteboard Markers (Set)", sku: "MRK-WHT-SET", description: "Set of 4 whiteboard markers", categoryIndex: 1, quantity: 18, minQuantity: 10, unitPrice: "6.50", unit: "set" },
  { name: "Office Chair Ergonomic", sku: "CHR-ERG-01", description: "Height adjustable ergonomic chair", categoryIndex: 2, quantity: 12, minQuantity: 5, unitPrice: "449.00", unit: "pcs" },
  { name: "Standing Desk 140cm", sku: "DSK-STD-140", description: "Height adjustable standing desk", categoryIndex: 2, quantity: 6, minQuantity: 3, unitPrice: "699.00", unit: "pcs" },
  { name: "Filing Cabinet 3-Drawer", sku: "CAB-FIL-3D", description: "3-drawer metal filing cabinet", categoryIndex: 2, quantity: 8, minQuantity: 3, unitPrice: "189.00", unit: "pcs" },
  { name: "Safety Helmet", sku: "SAF-HLM-01", description: "EN397 certified safety helmet", categoryIndex: 3, quantity: 50, minQuantity: 20, unitPrice: "15.99", unit: "pcs" },
  { name: "Nitrile Gloves L (Box)", sku: "GLV-NIT-L", description: "100 disposable nitrile gloves", categoryIndex: 3, quantity: 2, minQuantity: 10, unitPrice: "12.99", unit: "box" },
  { name: "Hi-Vis Vest Yellow", sku: "VIS-YLW-M", description: "High visibility safety vest", categoryIndex: 3, quantity: 25, minQuantity: 10, unitPrice: "9.99", unit: "pcs" },
  { name: "Multi-Purpose Cleaner 5L", sku: "CLN-MPU-5L", description: "Industrial multi-purpose cleaner", categoryIndex: 4, quantity: 35, minQuantity: 10, unitPrice: "22.50", unit: "bottle" },
  { name: "Microfiber Cloths (Pack 10)", sku: "CLT-MFB-10", description: "Pack of 10 microfiber cleaning cloths", categoryIndex: 4, quantity: 60, minQuantity: 20, unitPrice: "14.99", unit: "pack" },
];

export async function seedIfEmpty() {
  const [{ value: productCount }] = await db.select({ value: count() }).from(productsTable);

  if (productCount > 0) {
    logger.info({ productCount }, "Database already has products, skipping seed");
    return;
  }

  logger.info("Database is empty — seeding sample inventory data");

  // Insert categories
  const insertedCategories = await db.insert(categoriesTable).values(SEED_CATEGORIES).returning();

  // Insert products with correct categoryId references
  const products = SEED_PRODUCTS.map(p => ({
    name: p.name,
    sku: p.sku,
    description: p.description,
    categoryId: insertedCategories[p.categoryIndex].id,
    quantity: p.quantity,
    minQuantity: p.minQuantity,
    unitPrice: p.unitPrice,
    unit: p.unit,
  }));

  await db.insert(productsTable).values(products);

  logger.info({ categories: insertedCategories.length, products: products.length }, "Seed complete");
}
