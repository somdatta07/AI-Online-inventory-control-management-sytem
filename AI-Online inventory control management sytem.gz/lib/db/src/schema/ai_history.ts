import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const aiHistoryTable = pgTable("ai_history", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  insight: text("insight").notNull(),
  recommendations: jsonb("recommendations").notNull().$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAiHistorySchema = createInsertSchema(aiHistoryTable).omit({ id: true, createdAt: true });
export type InsertAiHistory = z.infer<typeof insertAiHistorySchema>;
export type AiHistory = typeof aiHistoryTable.$inferSelect;
